# Practice Data — Mask Number Only Direction Patch

## Goal

Remove the extra L/R experiment buttons and make the scanner assume the preferred direction-detection method is:

1. Read the number first.
2. If the number is not read successfully, stop and flag the cell for review.
3. If the number is read successfully, mask/remove the detected number area from the full white value-box crop.
4. Scan the masked remainder for `L` or `R`.
5. Combine the result into the final directional value.

## Scope

Apply this only to directional columns:
- Side Angle
- Sidespin
- Offline

All other columns keep the normal cell-by-cell OCR path.

## UI changes

### Remove these old experiment buttons
- Show L/R crops
- Right edge
- Bottom-right
- Wide scan
- Shape scan
- Direction review

### Replace with a single production method
Use one directional method only:
- `Mask number → scan L/R`

This does not need to be a visible button if the app is now treating it as the default directional-cell path.
If a visible control remains, it should be one simple button only.

## Feedback / loading

Add simple clear feedback while digitising directional cells:
- `Scanning directional number...`
- `Number found: 3.7`
- `Masking number and checking L/R...`
- `Direction found: R`
- `Direction missing — review needed`

For scan progress, keep the normal overall feedback:
- `Digitising cell 74/130...`
- `Directional cells: 12 checked, 3 need review`

## Important implementation rule

The direction scan must use:
- the full detected white value-box crop as source
- the detected number area as the region to mask
- the masked remainder as the L/R scan input

Do **not** use the old right-edge / bottom-right / shape experiment flows.
Do **not** crop only around the strongest text blob before scanning direction.

## Intended behaviour

### If number succeeds
Example:
- cell contains `3.7 R`
- number OCR reads `3.7`
- number area is masked
- remainder scan reads `R`
- final value becomes `3.7R`

### If number fails
- stop
- flag cell for review
- do not try to force L/R from an unusable cell

### If number succeeds but L/R fails
- keep numeric value
- mark as `direction missing`
- row should still remain reviewable rather than thrown away entirely

## Parking the rest

All other L/R experiment ideas are parked.
This patch should simplify the scanner rather than add more branching.
