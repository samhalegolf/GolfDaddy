"use strict";

exports.handler = async function(event){
  if(event.httpMethod !== "POST") return json(405, {error:"Method not allowed"});

  var payload;
  try{ payload = JSON.parse(event.body || "{}"); }
  catch(error){ return json(400, {error:"Invalid JSON"}); }

  var account = sanitizeAccount(payload.account || {});
  var profile = sanitizeProfile(payload.profile || {});
  var eventName = text(payload.event || "account-sync", 80);

  if(!account.account_id) return json(400, {error:"Missing account id"});
  if(!account.email) return json(400, {error:"Missing account email"});

  var supabaseUrl = env("SUPABASE_URL").replace(/\/+$/, "");
  var serviceKey = env("SUPABASE_SERVICE_ROLE_KEY");
  if(!supabaseUrl || !serviceKey){
    return json(503, {error:"Supabase is not configured", configured:false});
  }

  var now = new Date().toISOString();
  account.updated_at = account.updated_at || now;
  account.last_synced_at = now;
  profile.updated_at = profile.updated_at || now;
  profile.last_synced_at = now;

  var authResult = await upsertAuthUser(supabaseUrl, serviceKey, account, profile, eventName);
  var accountResult = await upsertRest(supabaseUrl, serviceKey, "clarity_app_accounts", account, "account_id");
  var profileResult = profile.profile_id ? await upsertRest(supabaseUrl, serviceKey, "clarity_app_profiles", profile, "profile_id") : {stored:false, skipped:true};

  var stored = !!(accountResult.stored || profileResult.stored || authResult.created || authResult.exists);
  return json(stored ? 200 : 502, {
    ok: stored,
    auth: publicResult(authResult),
    account: publicResult(accountResult),
    profile: publicResult(profileResult),
    event: eventName
  });
};

async function upsertAuthUser(base, key, account, profile, eventName){
  var metadata = {
    clarity_account_id: account.account_id,
    clarity_profile_id: account.profile_id || profile.profile_id || "",
    clarity_role: account.role || "player",
    clarity_source: "clarity-caddie-local-sync",
    clarity_last_event: eventName
  };
  var body = {
    email: account.email,
    email_confirm: true,
    user_metadata: {
      name: account.name || "",
      clarity_profile: metadata
    },
    app_metadata: metadata
  };

  try{
    var response = await fetch(base + "/auth/v1/admin/users", {
      method:"POST",
      headers: headers(key),
      body: JSON.stringify(body)
    });
    var data = await response.json().catch(function(){return null;});
    if(response.ok) return {created:true, id:data && data.id || null, status:response.status};

    var message = JSON.stringify(data || {}).toLowerCase();
    if(response.status === 400 || response.status === 422){
      if(message.includes("already") || message.includes("registered") || message.includes("exists")){
        return {exists:true, status:response.status};
      }
    }
    return {created:false, status:response.status, details:data};
  }catch(error){
    return {created:false, status:0, details:text(error && error.message || error, 300)};
  }
}

async function upsertRest(base, key, table, row, conflictKey){
  try{
    var response = await fetch(base + "/rest/v1/" + encodeURIComponent(table) + "?on_conflict=" + encodeURIComponent(conflictKey), {
      method:"POST",
      headers:Object.assign(headers(key), {"Prefer":"resolution=merge-duplicates,return=representation"}),
      body:JSON.stringify(row)
    });
    var data = await response.json().catch(function(){return null;});
    if(response.ok){
      var created = Array.isArray(data) ? data[0] : data;
      return {stored:true, id:created && (created.id || created[conflictKey]) || null, status:response.status};
    }
    return {stored:false, status:response.status, details:data};
  }catch(error){
    return {stored:false, status:0, details:text(error && error.message || error, 300)};
  }
}

function headers(key){
  return {
    "apikey": key,
    "Authorization": "Bearer " + key,
    "Content-Type": "application/json"
  };
}

function sanitizeAccount(input){
  return {
    account_id:text(input.accountId || input.account_id, 120),
    profile_id:text(input.profileId || input.profile_id, 120),
    name:text(input.name, 180),
    email:email(input.email),
    role:role(input.role),
    linked_coach_ids:arrayText(input.linkedCoachIds || input.linked_coach_ids, 40),
    linked_player_ids:arrayText(input.linkedPlayerIds || input.linked_player_ids, 200),
    created_by_coach_id:text(input.createdByCoachId || input.created_by_coach_id, 120),
    requires_password_setup:!!(input.requiresPasswordSetup || input.requires_password_setup),
    created_at:dateText(input.createdAt || input.created_at),
    updated_at:dateText(input.updatedAt || input.updated_at),
    last_login_at:dateText(input.lastLoginAt || input.last_login_at)
  };
}

function sanitizeProfile(input){
  return {
    profile_id:text(input.id || input.profileId || input.profile_id, 120),
    account_id:text(input.accountId || input.account_id, 120),
    name:text(input.name, 180),
    email:email(input.email),
    permission:role(input.permission || input.accountPermission || input.role),
    mode:text(input.mode, 40),
    handedness:text(input.handedness, 20),
    consistency:text(input.consistency || input.skillLevel, 40),
    face_offset_deg:numberOrNull(input.faceOffsetDeg || input.centralFaceOffsetDeg),
    bag_json:Array.isArray(input.bag) ? input.bag.slice(0, 40) : [],
    onboarding_complete:!!input.onboardingComplete,
    created_at:dateText(input.createdAt || input.created_at),
    updated_at:dateText(input.updatedAt || input.updated_at)
  };
}

function publicResult(result){
  if(!result) return null;
  return {
    stored:!!result.stored,
    created:!!result.created,
    exists:!!result.exists,
    skipped:!!result.skipped,
    id:result.id || null,
    status:result.status || 0,
    error:result.details && (result.details.message || result.details.error || result.details.code || result.details.hint) || null
  };
}

function env(name){ return process.env[name] || ""; }
function text(value, limit){ var input=String(value || "").trim(); return input.length>limit ? input.slice(0, limit) : input; }
function email(value){ var input=text(value, 240).toLowerCase(); return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input) ? input : ""; }
function role(value){ var key=text(value || "player", 60).toLowerCase().replace(/[\s_-]+/g, ""); return key==="admin" ? "admin" : key==="coach" ? "coach" : (key==="subscribed"||key==="subscriber"||key==="subscribedplayer" ? "subscribedPlayer" : "player"); }
function arrayText(value, limit){ return Array.isArray(value) ? value.slice(0, limit).map(function(item){return text(item, 120);}).filter(Boolean) : []; }
function dateText(value){ var input=text(value, 80); return input && !Number.isNaN(Date.parse(input)) ? new Date(input).toISOString() : null; }
function numberOrNull(value){ var n=Number(value); return Number.isFinite(n) ? n : null; }
function json(statusCode, body){ return {statusCode:statusCode, headers:{"Content-Type":"application/json","Cache-Control":"no-store"}, body:JSON.stringify(body)}; }
