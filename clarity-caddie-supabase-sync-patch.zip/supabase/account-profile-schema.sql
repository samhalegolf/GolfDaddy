-- Clarity Caddie account/profile sync tables
-- Run this in Supabase SQL editor before relying on table-backed account sync.

create table if not exists public.clarity_app_accounts (
  account_id text primary key,
  profile_id text,
  name text,
  email text not null unique,
  role text not null default 'player',
  linked_coach_ids jsonb not null default '[]'::jsonb,
  linked_player_ids jsonb not null default '[]'::jsonb,
  created_by_coach_id text,
  requires_password_setup boolean not null default false,
  created_at timestamptz,
  updated_at timestamptz,
  last_login_at timestamptz,
  last_synced_at timestamptz not null default now()
);

create table if not exists public.clarity_app_profiles (
  profile_id text primary key,
  account_id text references public.clarity_app_accounts(account_id) on delete cascade,
  name text,
  email text,
  permission text not null default 'player',
  mode text,
  handedness text,
  consistency text,
  face_offset_deg numeric,
  bag_json jsonb not null default '[]'::jsonb,
  onboarding_complete boolean not null default false,
  created_at timestamptz,
  updated_at timestamptz,
  last_synced_at timestamptz not null default now()
);

alter table public.clarity_app_accounts enable row level security;
alter table public.clarity_app_profiles enable row level security;

-- The Netlify function writes with the service-role key, so no public insert/update policies are required.
