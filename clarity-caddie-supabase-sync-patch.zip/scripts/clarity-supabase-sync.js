(function(){
  "use strict";

  var ENDPOINT = "/api/account-sync";
  var QUEUE_KEY = "clarity_supabase_sync_queue_v1";
  var LAST_STATUS_KEY = "clarity_supabase_sync_status_v1";
  var inFlight = false;
  var installed = false;

  function safe(fn, fallback){ try{return fn();}catch(e){return fallback;} }
  function accountsApi(){ return window.GolfDaddyAccounts || window.ClarityCaddieAccounts || null; }
  function profilesApi(){ return window.GolfDaddyProfiles || window.ClarityCaddieProfiles || null; }
  function state(){ var api=accountsApi(); return api && typeof api.state === "function" ? api.state() : null; }
  function profiles(){ var api=profilesApi(); var loaded=api && typeof api.load === "function" ? api.load() : null; return loaded && Array.isArray(loaded.profiles) ? loaded.profiles : []; }
  function profileById(id){ return profiles().find(function(p){return p && p.id === id;}) || null; }
  function accountById(id){ var s=state(); return s && Array.isArray(s.accounts) ? s.accounts.find(function(a){return a && a.accountId === id;}) || null : null; }
  function normaliseEmail(email){ return String(email || "").trim().toLowerCase(); }
  function canSyncAccount(account){ return !!(account && account.accountId && normaliseEmail(account.email).includes("@") && !normaliseEmail(account.email).endsWith("@clarity.local")); }

  function readQueue(){ return safe(function(){ var q=JSON.parse(localStorage.getItem(QUEUE_KEY)||"[]"); return Array.isArray(q)?q:[]; }, []); }
  function writeQueue(queue){ safe(function(){ localStorage.setItem(QUEUE_KEY, JSON.stringify(queue.slice(-80))); }); }
  function setStatus(status){ safe(function(){ localStorage.setItem(LAST_STATUS_KEY, JSON.stringify(Object.assign({at:new Date().toISOString()}, status || {}))); }); }

  function enqueue(account, profile, eventName){
    if(!canSyncAccount(account)) return;
    var queue = readQueue();
    queue.push({account:account, profile:profile || profileById(account.profileId), event:eventName || "account-save", queuedAt:new Date().toISOString()});
    writeQueue(queue);
    flushSoon();
  }

  function syncAccount(accountId, eventName){
    var account = typeof accountId === "object" ? accountId : accountById(accountId);
    if(!account) return;
    enqueue(account, profileById(account.profileId), eventName || "account-sync");
  }

  function syncAll(eventName){
    var s=state();
    if(!s || !Array.isArray(s.accounts)) return;
    s.accounts.forEach(function(account){ syncAccount(account, eventName || "account-sync-all"); });
  }

  function flushSoon(){ setTimeout(flush, 80); }

  async function flush(){
    if(inFlight) return;
    var queue = readQueue();
    if(!queue.length) return;
    inFlight = true;
    var next = queue.shift();
    writeQueue(queue);
    try{
      var response = await fetch(ENDPOINT, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(next)
      });
      var body = await response.json().catch(function(){return null;});
      if(!response.ok || !body || !body.ok){
        queue = readQueue();
        queue.unshift(next);
        writeQueue(queue.slice(0, 80));
        setStatus({ok:false, event:next.event, status:response.status, error:body && body.error || "sync_failed"});
        return;
      }
      setStatus({ok:true, event:next.event, accountId:next.account && next.account.accountId, result:body});
    }catch(error){
      queue = readQueue();
      queue.unshift(next);
      writeQueue(queue.slice(0, 80));
      setStatus({ok:false, event:next && next.event, error:String(error && error.message || error || "network_error")});
      return;
    }finally{
      inFlight = false;
    }
    if(readQueue().length) flushSoon();
  }

  function wrap(name, after){
    var api=accountsApi();
    if(!api || typeof api[name] !== "function" || api[name].__claritySupabaseWrapped) return;
    var original=api[name];
    api[name]=function(){
      var result = original.apply(this, arguments);
      safe(function(){ after(result, arguments); });
      return result;
    };
    api[name].__claritySupabaseWrapped = true;
  }

  function install(){
    if(installed) return;
    var api=accountsApi();
    if(!api) return;
    installed = true;
    wrap("signup", function(account){ syncAccount(account, "signup"); });
    wrap("update", function(account){ syncAccount(account, "account-update"); });
    wrap("addPlayer", function(account){ syncAccount(account, "coach-add-player"); });
    wrap("addCoach", function(account){ syncAccount(account, "admin-add-coach"); });
    wrap("login", function(account){ syncAccount(account, "login"); });
    syncAll("boot-existing-local-accounts");
    flushSoon();
  }

  window.ClaritySupabaseSync = {install:install, syncAccount:syncAccount, syncAll:syncAll, flush:flush, status:function(){return safe(function(){return JSON.parse(localStorage.getItem(LAST_STATUS_KEY)||"null");}, null);}};
  if(document.readyState === "loading") document.addEventListener("DOMContentLoaded", function(){ setTimeout(install, 150); });
  else setTimeout(install, 150);
})();
