/* Wiring only. Route transitions toggle body classes here and nowhere else, and
   each transition finishes its own cleanup — no pollers exist to catch strays. */
(function () {
  "use strict";
  var app = (window.ClarityApp = window.ClarityApp || {});

  /* The round currently in play, and which kind of map it's using - drives
     the background update check below. Cleared whenever play stops so a
     check in flight for a course just left can't land on the next one. */
  var activeCourse = null;
  var activeMapType = null;   // "object" | "published" | null (nothing usable yet)
  var mapUpdateDismissed = false;
  var updateCheckToken = 0;

  /* Build the Marshal and hand it the effects it is allowed to cause. It is
     pure by construction — no globals, no DOM — so everything with a side
     effect arrives here, which is also why the whole transition table can be
     driven in node (dev/marshal.test.js).

     Note what is NOT in this list: anything that draws. The Painter is a Scene
     subscriber, not an effect, because drawing is not something the Marshal
     asks for — it is what the Scene IS. */
  function ensureMarshal() {
    if (app.marshal) return app.marshal;
    app.marshal = app.createMarshal({
      trace: app.trace || null,
      /* The engine's own target rule: the green when the bag reaches it, the
         fairway layup point when it cannot. */
      defaultTarget: function (start, rec) {
        var green = rec && rec.green;
        if (!green) return null;
        if (!window.GDBubbleEngine) return green;
        try {
          window.GDBubbleEngine.setShot(start, null);
          return window.GDBubbleEngine.targetForGreenCentre(green, { hole: rec.holeNumber }) || green;
        } catch (e) { return green; }
      },
      effects: {
        roundStarted: function (courseKey) {
          if (app.courseData) app.courseData.startRound(courseKey);
          if (app.pin) app.pin.startRound();
          if (app.scorecard) app.scorecard.setCourse(courseKey);
          if (app.gps) app.gps.start();
          if (app.wakeLock) app.wakeLock.start();
        },
        roundEnded: function () {
          if (app.gps) app.gps.stop();
          if (app.wakeLock) app.wakeLock.stop();
        },
        holeEntered: function (hole, rec) {
          if (app.pin) app.pin.startHole(hole);
          if (app.undo) app.undo.clear();
          if (app.resume) app.resume.setHole(hole);
          if (window.GDBubbleEngine && rec) {
            window.GDBubbleEngine.setHoleContext({
              hole: hole, tee: rec.tee, green: rec.green, route: rec.route
            });
          }
        },
        shotChanged: function (start, target) {
          if (window.GDBubbleEngine) window.GDBubbleEngine.setShot(start || null, target || null);
        },
        /* GPS Play's only analytical output. Wrapped because nothing about
           Course Data may interrupt a round. */
        shotCompleted: function (shot, meta) {
          try { if (app.courseData) app.courseData.submit(shot, meta); } catch (e) {}
        },
        scoreSet: function (hole, strokes) {
          if (app.scorecard && app.scorecard.setScore) app.scorecard.setScore(hole, strokes);
        }
      }
    });
    if (app.painter) app.painter.attach(app.marshal);
    /* The only two things that turn the outside world into Signals. A fix that
       is not trusted is refused inside the Marshal, not here — this file does
       not get to decide what counts. */
    if (app.gps) {
      app.gps.onFix(function (fix) { app.marshal.signal("FIX_RECEIVED", { point: fix }); });
      app.gps.onStatus(function (status) {
        renderGpsNotice(status);
        if (status === "denied" || status === "unsupported") app.marshal.signal("FIX_LOST");
      });
    }
    return app.marshal;
  }

  function startRound(course, pkg) {
    ensureMarshal().signal("ROUND_OPENED", {
      courseKey: app.courseKey(course.courseId),
      pkg: pkg || null,
      centre: Number.isFinite(course.courseLat) && Number.isFinite(course.courseLng)
        ? { lat: course.courseLat, lng: course.courseLng } : null,
      nines: app.nines ? app.nines.forPackage(app.courseKey(course.courseId), pkg) : null
    });
  }

  /* Which SCREEN the app is on — home, play or sign-in — is genuinely outside
     the Marshal's remit: it owns the round, not the route. But an unattributed
     write to a watched element is a Leak whoever did it, and it should be,
     so this declares itself instead of quietly slipping past. Trace showed it
     as `body.class.toggle ← boot.js` on the very first boot, which is the
     mechanism working. */
  function show(route) {
    function paintRoute() {
      ["home", "play", "signin"].forEach(function (name) {
        document.body.classList.toggle("route-" + name, route === name);
      });
    }
    if (app.trace) app.trace.paint("ROUTE_CHANGED", route, paintRoute);
    else paintRoute();
    if (route !== "play") {
      if (app.marshal) app.marshal.signal("END_ROUND");
      if (app.painter && app.painter.detach) app.painter.detach();
      if (app.gps) app.gps.stop();
      if (app.wakeLock) app.wakeLock.stop();
      activeCourse = null;
      activeMapType = null;
    }
    if (route === "home") renderAccountState();
  }

  /* Visible from first paint (see index.html) so it covers both the "which
     route" decision and, on a hand-off, the course-package fetch — hidden
     once there's something real underneath it to show. */
  function hideLoadingScreen() {
    var el = document.getElementById("loadingScreen");
    if (el) el.classList.add("hiddenState");
  }

  /* Exits GPS play back to the main site - the picker there is the only
     other entry point into this page, so there's nothing of this page's own
     to navigate back to. Home lands on the site root; Back prefers actual
     browser history so it returns to the picker they came from. GPS
     Settings deep-links into the old shell's GPS settings panel, which
     checks for this param on boot the same way it already does for the
     password-reset route. */
  function exitToMainSite() {
    window.location.href = "/";
  }
  /* During play, Back peels one layer at a time. Green focus goes first: it is
     a layer over the hole rather than a place, so closing it returns to the
     same hole overview with the shot, standing location, club, bubble and pin
     all intact. Then the most recent wind/pin change is undone - only once
     there is nothing left to close or undo does Back fall through to leaving
     GPS play the way it always has. */
  function exitBack() {
    /* Back peels one layer at a time, and the Marshal owns what a layer is:
       it answers false when there was nothing to close, so Back falls through
       to its next meaning rather than this file guessing at the play state. */
    if (app.marshal && app.marshal.signal("BACK")) return;
    if (app.undo && app.undo.pop()) return;
    if (window.history.length > 1) window.history.back();
    else exitToMainSite();
  }

  /* The location-denied notice. Only "denied" shows it: that is the one status
     the player can act on, and the one that will never resolve on its own.
     Dismissal lasts the round - re-nagging on every status event would be worse
     than the silence it replaces. */
  var gpsNoticeDismissed = false;
  function renderGpsNotice(status) {
    var el = document.getElementById("gpsNotice");
    if (!el) return;
    el.classList.toggle("hiddenState", gpsNoticeDismissed || status !== "denied");
  }

  /* Android's hardware Back, routed to the same handler as the on-screen one.
     Without a listener the system default pops the WebView's history or closes
     the app outright, which mid-round is the worst thing this app can do.

     This page does not load gd-native-back-button.js on purpose: that module
     asks GDShell for the current route, GDShell does not exist here, and a
     missing route reads as "root" - so every Back press would have reached its
     exitApp() branch and dropped the round. exitBack already encodes this
     page's real semantics (undo a wind/pin change, then history, then the main
     site), so Back means the same thing whichever way it is pressed.

     iOS has no hardware back button and web has no plugin, so both no-op. */
  function installNativeBack() {
    if (!(window.GDNative && window.GDNative.isNative && window.GDNative.platform === "android")) return false;
    var cap = window.Capacitor;
    var api = cap && cap.Plugins && cap.Plugins.App;
    if (!api || typeof api.addListener !== "function") return false;
    try { api.addListener("backButton", function () { exitBack(); }); } catch (e) { return false; }
    return true;
  }
  /* GPS Settings is a sheet in this page now, not a hand-off. It used to
     navigate to /?openGpsSettings=1, which meant leaving the round entirely
     and landing on the main site's home shell — and if you were not signed
     in, the legacy panel bailed to "Sign in first" and you just stayed on
     home. The four settings that survived the rebuild are all local display
     preferences, so none of that round trip was buying anything. */
  function openGpsSettings() {
    if (app.toolRail) app.toolRail.close();
    if (app.gpsSettings) app.gpsSettings.open();
  }

  /* Tapping the hole number opens a grid of every hole in play - a straight
     jump, not just stepping one at a time. Built fresh each open since the
     available holes can change mid-round (a multi-nine pairing swap). */
  /* The grid itself is drawn by the Painter, because the tile that matters is
     the flagged one — a hole still holding a shot with no end — and that is a
     view of the Marshal's record, not something this file can know. Opening the
     panel is all that is left here. */
  function openHolePicker() {
    document.getElementById("holePickerPanel").classList.remove("hiddenState");
  }
  function closeHolePicker() {
    document.getElementById("holePickerPanel").classList.add("hiddenState");
  }

  function renderAccountState() {
    var state = document.getElementById("accountState");
    var action = document.getElementById("accountAction");
    var signedIn = app.account.signedIn();
    state.textContent = signedIn ? app.account.label() : "Not signed in";
    action.textContent = signedIn ? "Sign out" : "Sign in";
  }

  async function submitSignIn(event) {
    event.preventDefault();
    var status = document.getElementById("signInStatus");
    var submit = document.getElementById("signInSubmit");
    submit.disabled = true;
    status.textContent = "Signing in…";
    try {
      await app.account.login(
        document.getElementById("signInEmail").value,
        document.getElementById("signInPassword").value
      );
      document.getElementById("signInPassword").value = "";
      status.textContent = "";
      show("home");
    } catch (error) {
      status.textContent = (error && error.message) || "Could not sign in. Check your connection.";
    } finally {
      submit.disabled = false;
    }
  }

  function mapTypeOf(pkg) {
    if (pkg && pkg.status === "full-map-ready") return "published";
    if (pkg && pkg.status === "lite-geo-ready") return "object";
    return null;   // processing/manual-required/none - nothing worth keeping yet
  }

  /* Only called with a package that actually has geometry - the course
     picker's own placeholder/processing/none answers are never saved, or
     the library would fill up with empty records for unmapped courses. */
  function saveCourseToLibrary(course, pkg) {
    var mapType = mapTypeOf(pkg);
    if (!mapType) return null;
    return app.courseStore.save({
      courseId: course.courseId,
      courseName: course.courseName,
      mapType: mapType,
      /* pkg.objectsVersion, NOT pkg.geometryVersion: the freshness check
         compares this against /api/course-library's objects_version, and
         geometryVersion is a different field entirely (the mapper algorithm
         version, "v1"). Storing the wrong one is what made every course read
         as permanently "Update available". */
      objectsVersion: pkg.objectsVersion || null,
      mapVersion: pkg.packageVersion || null,
      pkg: pkg
    });
  }

  /* If the course started on the object map (or nothing at all), check once
     per hole change whether a published map has since appeared - a real
     answer, not guessed at, since the same /api/course-package fetch used
     everywhere else already reports it. Fire-and-forget: this runs after a
     hole change already resolved, never blocks navigation. */
  async function checkForMapUpdate() {
    if (activeMapType === "published" || mapUpdateDismissed || !activeCourse) return;
    var course = activeCourse;
    var token = ++updateCheckToken;
    var pkg = await app.fetchCoursePackage({
      courseId: course.courseId, courseName: course.courseName,
      courseLat: course.courseLat, courseLng: course.courseLng
    });
    if (token !== updateCheckToken || activeCourse !== course) return;   // superseded: left/changed course
    var mapType = mapTypeOf(pkg);
    if (mapType && mapType !== activeMapType) showMapUpdateBar(course, pkg, mapType);
  }

  /* A prompt, not an auto-switch - the auto-download bias only applies to a
     map that's already there when the round STARTS (openPlay saves it with
     no prompt at all); one that arrives mid-round asks first, since the
     player is already using the map they have. */
  function showMapUpdateBar(course, pkg, mapType) {
    document.getElementById("mapUpdateLabel").textContent =
      mapType === "published" ? "Published map available" : "Course map available";
    var bar = document.getElementById("mapUpdateBar");
    bar.classList.remove("hiddenState");
    document.getElementById("mapUpdateDownload").onclick = function () {
      saveCourseToLibrary(course, pkg);
      activeMapType = mapType;
      app.marshal.signal("PACKAGE_UPDATED", { pkg: pkg });
      bar.classList.add("hiddenState");
    };
  }

  /* Resuming lands on the hole the round reached. start() has already opened
     the first hole in play, so this is a second transition rather than a
     parameter to it - which also means a stale or nonsense hole number simply
     leaves the player on hole 1 rather than failing the whole entry. */
  function goResumeHole(hole) {
    var n = Number(hole);
    if (!Number.isFinite(n) || n < 1) return;
    if (app.marshal.round().hole === n) return;
    app.marshal.signal("VIEW_HOLE_CHANGED", { hole: n });
  }

  async function openPlay(course, resumeHole) {
    show("play");
    activeCourse = course;
    mapUpdateDismissed = false;
    gpsNoticeDismissed = false;
    /* Record the round the moment it is genuinely up, so a phone that dies on
       the 7th tee still has somewhere to come back to. play.js keeps the hole
       current from here on. */
    if (app.resume) app.resume.setCourse(course);
    var cached = app.courseStore.load(course.courseId);
    var pkg = cached && cached.pkg;
    if (pkg) {
      /* Bias to the downloaded copy: play starts immediately, never waits
         on a network round-trip for a course already on the device. */
      activeMapType = cached.mapType;
      startRound(course, pkg);
      goResumeHole(resumeHole);
      hideLoadingScreen();
    } else {
      pkg = await app.fetchCoursePackage({
        courseId: course.courseId,
        courseName: course.courseName,
        courseLat: course.courseLat,
        courseLng: course.courseLng
      });
      activeMapType = mapTypeOf(pkg);
      /* null package → live map only. Normal, per the handover. */
      startRound(course, pkg);
      goResumeHole(resumeHole);
      hideLoadingScreen();
      saveCourseToLibrary(course, pkg);
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("accountAction").addEventListener("click", function () {
      if (app.account.signedIn()) { app.account.signOut(); renderAccountState(); }
      else show("signin");
    });
    document.getElementById("signInForm").addEventListener("submit", submitSignIn);
    document.getElementById("signInBack").addEventListener("click", function () { show("home"); });
    document.getElementById("globalBackBtn").addEventListener("click", exitBack);
    document.getElementById("globalHomeBtn").addEventListener("click", exitToMainSite);
    document.getElementById("railGpsSettings").addEventListener("click", openGpsSettings);
    /* The hole controls send their own Signals (painter.js). This listener is
       only the background "has a published map appeared" check riding along. */
    document.getElementById("prevHole").addEventListener("click", checkForMapUpdate);
    document.getElementById("nextHole").addEventListener("click", checkForMapUpdate);
    document.getElementById("holeNumber").addEventListener("click", openHolePicker);
    document.getElementById("holePickerClose").addEventListener("click", closeHolePicker);
    document.getElementById("mapUpdateDismiss").addEventListener("click", function () {
      mapUpdateDismissed = true;
      document.getElementById("mapUpdateBar").classList.add("hiddenState");
    });
    var handoffCourseId = new URLSearchParams(window.location.search).get("courseId");
    if (handoffCourseId) {
      openPlay(courseFromUrl(handoffCourseId),
        new URLSearchParams(window.location.search).get("hole"));
    } else {
      show("home");
      hideLoadingScreen();
    }
    document.getElementById("gpsNoticeDismiss").addEventListener("click", function () {
      gpsNoticeDismissed = true;
      document.getElementById("gpsNotice").classList.add("hiddenState");
    });
    app.courseDataFeedInstalled = !!(app.courseData && app.courseData.submit);
    app.basemap.prefetch();   // so base-layer choice is synchronous by map time
    app.nativeBackInstalled = installNativeBack();
    app.booted = true;   // boot-test canary: the last line of the load order ran
  });

  /* The old course picker hands off a confirmed, already-mapped course by navigating
     here with ?courseId=... (courseName/courseLat/courseLng optional) rather than
     re-entering its own picker screen. */
  /* Number(null) is 0, and so is Number("") — both finite, and both a real
     point in the Gulf of Guinea. The picker only appends courseLat/courseLng
     when its own row carried them, so a course handed off without them used to
     start the round with a centre 15,000km away, and every GPS fix was rejected
     for the whole round. Absent has to read as absent so the Marshal falls
     through to deriving the centre from the package's own geometry. */
  function coordParam(params, name) {
    var raw = params.get(name);
    if (raw === null || String(raw).trim() === "") return NaN;
    var n = Number(raw);
    return Number.isFinite(n) ? n : NaN;
  }

  function courseFromUrl(courseId) {
    var params = new URLSearchParams(window.location.search);
    return {
      courseId: courseId,
      courseName: params.get("courseName") || "",
      courseLat: coordParam(params, "courseLat"),
      courseLng: coordParam(params, "courseLng")
    };
  }
})();
