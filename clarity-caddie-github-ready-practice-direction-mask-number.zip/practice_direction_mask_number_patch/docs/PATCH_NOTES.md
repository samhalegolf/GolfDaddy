# Practice Direction Mask-Number Patch

This patch is intended to update directional-cell scanning for the Practice Data digitiser.

## Change summary

For directional columns only:
- Side Angle
- Sidespin
- Offline

The new method should:
1. Read the number first from the directional cell.
2. If the number is not successfully read, stop and flag the cell for review.
3. If the number is read successfully, mask/remove the number region from the full detected white value-box crop.
4. Pass the remaining crop to the L/R detector.
5. Combine the result as `number + direction`.

## Why

The main numeric text dominates OCR and drowns out the tiny L/R marker.
Masking the number after a successful numeric read lets the direction detector focus only on the leftover marker.

## Important implementation rule

The direction scan must use the full detected white value-box crop as its source, not a tighter OCR crop around the number.

## Suggested status wording

- "Scanning directional number..."
- "Masking number and checking L/R..."
- "Direction found: R"
- "Direction missing — review needed"

## Parking the rest

Other experiments should remain parked for now. This patch promotes only the mask-number directional method into the main path.
