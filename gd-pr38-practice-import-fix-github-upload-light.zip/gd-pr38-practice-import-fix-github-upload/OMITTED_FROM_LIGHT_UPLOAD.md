# Omitted from light GitHub upload

This package was created from `gd-pr38-practice-import-fix-backup.zip` but removes heavy/generated backup material so it can be uploaded more easily.

Omitted intentionally:
- `archive/` — legacy patch history and duplicated backup zips.
- `dist/` — generated/static build copy of the app.
- `*.zip` — nested backup archives already represented by source files.
- `.git` — local worktree pointer from the temporary machine path.
- `node_modules/`, `.netlify/`, `.DS_Store` if present.

Kept:
- root app files such as `index.html`, `package.json`, `netlify.toml`.
- `assets/`, `functions/`, `scripts/`, `styles/`, `supabase/`, `docs/`, `patches/`.
- handover and update notes in Markdown.

After importing this to GitHub, regenerate `dist/` from the project rather than committing the copied `dist/` folder.
